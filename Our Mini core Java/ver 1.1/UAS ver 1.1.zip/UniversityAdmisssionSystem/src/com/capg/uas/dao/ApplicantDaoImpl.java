package com.capg.uas.dao;

public class ApplicantDaoImpl implements IApplicantDao {

}
