package com.capg.uas.dao;

public interface IApplicantDao {

}
