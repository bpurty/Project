package com.capg.uas.service;

public class ApplicantServiceImpl implements IApplicantService {

}
