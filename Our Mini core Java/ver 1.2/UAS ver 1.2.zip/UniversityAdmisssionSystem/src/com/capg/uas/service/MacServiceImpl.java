package com.capg.uas.service;

public class MacServiceImpl implements IMacService {

}
