package com.capg.uas.service;

public class AdminServiceImpl implements IAdminService {

}
