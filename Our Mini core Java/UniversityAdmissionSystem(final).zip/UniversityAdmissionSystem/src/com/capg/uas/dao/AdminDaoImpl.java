package com.capg.uas.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capg.uas.bean.Applicant;
import com.capg.uas.bean.ProgramOffered;
import com.capg.uas.bean.ProgramScheduled;
import com.capg.uas.bean.Users;
import com.capg.uas.exception.UASException;
import com.capg.uas.util.ConnectionProvider;

public class AdminDaoImpl implements IAdminDao {

	public Logger log = Logger.getLogger("AdminDAO");
	

	@Override
	public Users getUserByName(String userName) throws UASException {
		Users user = null;
		try (Connection connection = ConnectionProvider.DEFAULT_INSTANCE
				.getConnection();
				PreparedStatement statement = connection
						.prepareStatement(IQueryMapper.GET_USER)) {

			statement.setString(1, userName);

			ResultSet result = statement.executeQuery();
			if (result.next()) {
				user = new Users();
				user.setLoginId(result.getString(1));
				user.setPassword(result.getString(2));
				user.setRole(result.getString(3));
			}
		} catch (SQLException exception) {
			log.error(exception);
			throw new UASException("Unable To Fetch Records");
		}
		return user;
	}

	@Override
	public String addProgramOffered(ProgramOffered progOffered)
			throws UASException {
		String programName = null;
		
		
		Connection connection = ConnectionProvider.DEFAULT_INSTANCE.getConnection();
		PreparedStatement addStatement = null;
		
		
		if (progOffered != null) {
			
			try {
				addStatement = connection.prepareStatement(IQueryMapper.ADD_PROGRAM_OFFERED_QUERY);
				addStatement.setString(1, progOffered.getProgName());
				addStatement.setString(2, progOffered.getDesc());
				addStatement.setString(3, progOffered.getAppEligibility());
				addStatement.setInt(4, progOffered.getDuration());
				addStatement.setString(5, progOffered.getDegreeOffered());
				int count = addStatement.executeUpdate();
				
				if (count > 0){
						log.info("Program Offered details added successfully");
						programName=progOffered.getProgName();
					
				}
				else {
					log.error("Program Offered insertion failed");
					throw new UASException("Inserting Program Offered details failed ");
				}
				
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
				log.error(sqlException+"Technical error");
				throw new UASException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					
					addStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					sqlException.printStackTrace();
					log.error(sqlException.getMessage()+"Database connection not closed");
					throw new UASException("Error in closing database connection");

				}
			}
		}
		return programName;
	}

	@Override
	public String updateProgramOffered(ProgramOffered progOffered)
			throws UASException {
		String programName = null;
		
		
		Connection connection = ConnectionProvider.DEFAULT_INSTANCE.getConnection();
		PreparedStatement updateStatement = null;
		
			try {
				
				updateStatement=connection.prepareStatement(IQueryMapper.UPDATE_PROGRAM_OFFERED_QUERY);
				updateStatement.setString(1, progOffered.getDesc());
				updateStatement.setString(2, progOffered.getAppEligibility());
				updateStatement.setString(3, progOffered.getProgName());
				int count = updateStatement.executeUpdate();

				if (count > 0){
					log.info("Program Offered details updated successfully:");
						programName=progOffered.getProgName();
					
				}
				else {
					log.error("Program details not updated ");
					throw new UASException("Updating Program Offered details failed ");
				}
				
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
				log.error(sqlException.getMessage()+"Technical problem");
				throw new UASException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					
					updateStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					sqlException.printStackTrace();
					log.error(sqlException.getMessage()+"Database connection not closed");
					throw new UASException("Error in closing database connection");

				}
			}
			
			return programName;
		}
		

		
	

	@Override
	public boolean deleteProgramOffered(String progName) throws UASException {
		
		boolean result = false;
		
		Connection connection = ConnectionProvider.DEFAULT_INSTANCE.getConnection();
		PreparedStatement deleteStatement = null;
		
			try {
				
				deleteStatement=connection.prepareStatement(IQueryMapper.DELETE_PROGRAM_OFFERED_QUERY);
				
				deleteStatement.setString(1, progName);
				int count = deleteStatement.executeUpdate();

				if (count > 0){
					log.info("Program Offered successfully deleted");
						result = true;
					
				}
				else {
					log.error("Deletion failed ");
					throw new UASException("Deleting Program Offered details failed ");
				}
				
			} catch (SQLException sqlException) {
				sqlException.printStackTrace();
				log.fatal(sqlException.getMessage()+"Technical problem");
				throw new UASException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					
					deleteStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					sqlException.printStackTrace();
					log.error(sqlException.getMessage()+"Database connection not closed");
					throw new UASException("Error in closing database connection");

				}
			}
			
			return result;
	}

	@Override
	public List<ProgramOffered> getAllOfferedPrograms() throws UASException {
		
		List<ProgramOffered> programOfferedList = new ArrayList<>();
		ResultSet resultSet = null;
		Connection connection = ConnectionProvider.DEFAULT_INSTANCE.getConnection();
		PreparedStatement listStatement = null;
		
		try {
			
			listStatement = connection.prepareStatement(IQueryMapper.LIST_PROGRAMS_OFFERED); 
			
			resultSet = listStatement.executeQuery();
			
			while(resultSet.next()){
				ProgramOffered programOffered = new ProgramOffered();
				programOffered.setProgName(resultSet.getString("ProgramName"));
				programOffered.setDesc(resultSet.getString("description"));
				programOffered.setAppEligibility(resultSet.getString("applicant_eligibility"));
				programOffered.setDuration(resultSet.getInt("duration"));
				programOffered.setDegreeOffered(resultSet.getString("degree_certificate_offered"));
				
				programOfferedList.add(programOffered);
			}

		} catch (SQLException exception) {
			log.error(exception);
			throw new UASException("Error in fetching data in DAO");
		} finally
		{
			try 
			{
				resultSet.close();
				listStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				log.error(sqlException.getMessage()+"Database connection not closed");
				throw new UASException("Error in closing database connection");
			}
		}
		return programOfferedList;
	}

	@Override
	public String addProgramScheduled(ProgramScheduled progScheduled)
			throws UASException {
		String programId = null;
		
		Connection connection = ConnectionProvider.DEFAULT_INSTANCE.getConnection();
		PreparedStatement addStatement = null;
		ResultSet resultSet = null;
		
		if (progScheduled != null) {
			
			try {
				addStatement = connection.prepareStatement(IQueryMapper.ADD_PROGRAM_SCHEDULED_QUERY);
				addStatement.setString(1, progScheduled.getScheduleProgId());
				addStatement.setString(2, progScheduled.getProgName());
				addStatement.setString(3, progScheduled.getLocation());
				addStatement.setDate(4, progScheduled.getStart());
				addStatement.setDate(4, progScheduled.getEnd());
				addStatement.setInt(6, progScheduled.getSessionsPerWeek());
				
				int count = addStatement.executeUpdate();
				
				if (count > 0){
						log.info("Program Schedule details added successfully");
						programId=progScheduled.getScheduleProgId();
					
				}
				else {
					log.error("Program Schedule details insertion failed ");
					throw new UASException("Inserting Program Scheduled failed ");
				}
				
			} catch (SQLException sqlException) {
				log.error(sqlException.getMessage()+"Technical problem");
				throw new UASException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					resultSet.close();
					addStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					sqlException.printStackTrace();
					log.error(sqlException.getMessage()+"Database connection not closed");
					throw new UASException("Error in closing database connection");

				}
			}
		}
		return programId;
	}

	@Override
	public boolean deleteProgramScheduled(String progId) throws UASException {
		
		boolean result = false;
		
		Connection connection = ConnectionProvider.DEFAULT_INSTANCE.getConnection();
		PreparedStatement deleteStatement = null;
		
			try {
				
				deleteStatement=connection.prepareStatement(IQueryMapper.DELETE_PROGRAM_SCHEDULED_QUERY);
				
				deleteStatement.setString(1, progId);
				int count = deleteStatement.executeUpdate();

				if (count > 0){
						log.info("Program Schedule deleted successfully:");
						result = true;
					
				}
				else {
					log.error("Deletion failed ");
					throw new UASException("Deleting Program Scheduled failed ");
				}
				
			} catch (SQLException sqlException) {
				log.error(sqlException.getMessage()+"Technical problem");
				throw new UASException("Tehnical problem occured refer log");
			}
			finally
			{
				try 
				{
					
					deleteStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					sqlException.printStackTrace();
					log.error(sqlException.getMessage()+"Database connection not closed");
					throw new UASException("Error in closing database connection");

				}
			}
			
			return result;
	}

	@Override
	public List<ProgramScheduled> getDatedProgramsSchedule(Date fromDateSQL,
			Date toDateSQL) throws UASException {
		List<ProgramScheduled> programScheduleList = new ArrayList<>();
		ResultSet resultSet = null;
		Connection connection = ConnectionProvider.DEFAULT_INSTANCE.getConnection();
		PreparedStatement listStatement = null;
		
		try {
			
			listStatement = connection.prepareStatement(IQueryMapper.LIST_PROGRAMS_OFFERED_DATES); 
			listStatement.setDate(1, fromDateSQL);
			listStatement.setDate(2, toDateSQL);
			resultSet = listStatement.executeQuery();
			
			
			while(resultSet.next()){
				ProgramScheduled programSchedule = new ProgramScheduled();
				programSchedule.setScheduleProgId(resultSet.getString("Scheduled_program_id"));
				programSchedule.setProgName(resultSet.getString("ProgramName"));
				programSchedule.setLocation(resultSet.getString("Location"));
				programSchedule.setStart(resultSet.getDate("start_date"));
				programSchedule.setEnd(resultSet.getDate("end_date"));
				programSchedule.setSessionsPerWeek(resultSet.getInt("session_per_week"));				
				programScheduleList.add(programSchedule);
			}

		} catch (SQLException except) {
			log.error(except);
			throw new UASException("Error in fetching data in DAO");
		} finally
		{
			try 
			{
				resultSet.close();
				listStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				log.error(sqlException.getMessage()+"Database connection not closed");
				throw new UASException("Error in closing database connection");
			}
		}
		return programScheduleList;
	}

	@Override
	public List<Applicant> viewCandidates(Applicant applicants)
			throws UASException {
		List<Applicant> appList = null;
		try (
				Connection connection = ConnectionProvider.DEFAULT_INSTANCE.getConnection();
				PreparedStatement statement = connection
						.prepareStatement(IQueryMapper.FIND_APPLICANT_PROG_ID_STATUS);) {
			
			statement.setString(1, applicants.getScheduleProgId());
			statement.setString(2, applicants.getStatus());
			ResultSet result = statement.executeQuery();

			appList = new ArrayList<Applicant>();
			while (result.next()) {
				Applicant applicant = new Applicant();
				applicant.setAppId(result.getInt("application_id"));
				applicant.setAppName(result.getString("full_name"));
				applicant.setAppDOB(result.getDate("date_of_birth"));
				applicant.setQualification(result
						.getString("highest_qualification"));
				applicant.setMarks(result.getInt("marks_obtained"));
				applicant.setGoals(result.getString("goals"));
				applicant.setEmailId(result.getString("email_id"));
				applicant.setScheduleProgId(result.getString("Scheduled_program_id"));
				applicant.setStatus(result.getString("status"));
				applicant.setDateOfInterview(result.getDate("Date_Of_Interview"));

				appList.add(applicant);
			}

			if (appList.size() == 0)
				appList = null;
			
		} catch (SQLException exp) {
			log.error(exp);
			throw new UASException("Unable To Fetch Applicants");
		}
		return appList;
	}

}
